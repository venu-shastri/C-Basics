﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVReader
{
    public class CSVCommentsReader
    {

        public string GetContents()
        {
            return "Patient Comments  From CSV File Version 2.0.0.0";
        }
    }
}
