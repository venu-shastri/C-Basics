﻿
namespace TestApp
{
    public delegate void StackStateChangeNotifyAdpater(string message);

    //Adaptee/Subscriber/EventHandler
    public class ConsoleLogger
    {
        public void WriteLog(string message)
        {
            System.Console.WriteLine(message);
        }
    }

    //EventSource
    public class ObservableStack<T>
    {
        //Event - Encapsulate
        private StackStateChangeNotifyAdpater StateChanged = null;
    
        //Subscribe
        public void Add_StateChanged(StackStateChangeNotifyAdpater eventHandler)
        {
            this.StateChanged += eventHandler;
        }

        //UnSubscribe
        public void Remove_StateChanged(StackStateChangeNotifyAdpater eventHandler)
        {
            this.StateChanged-= eventHandler;
        }
        public void Push(T item)
        {

            if (this.StateChanged != null)
            {
                this.StateChanged.Invoke("New Item Inserted "+item.ToString());
            }

        }
        public T Pop()
        {
            return default(T);
        }
        public void Refresh()
        {
            if(this.StateChanged!=null)
            {
                this.StateChanged.Invoke("Stack Reset");
            }
        }
    }

   
    class Program
    {
        static void Main()
        {
            ConsoleLogger _observer = new ConsoleLogger();

            ObservableStack<int> _stack = new ObservableStack<int>();
            StackStateChangeNotifyAdpater _adapter = new StackStateChangeNotifyAdpater(_observer.WriteLog);
            _stack.Add_StateChanged(_adapter);
            _stack.Push(10);
            _stack.Push(100);
            _stack.Push(1000);
            _stack.Push(10000);


        }
    }
}
