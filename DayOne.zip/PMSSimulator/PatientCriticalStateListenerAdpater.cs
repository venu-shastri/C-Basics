﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSSimulator
{
    public delegate void PatientCriticalStateListenerAdpater(string message);


  //public  class PatientCriticalStateListenerAdpater
  //  {
  //      DutyDoctorNotifier _docNotifier = new DutyDoctorNotifier();
  //      PatientCriticalStateLogger _logger = new PatientCriticalStateLogger();
  //      public void Invoke(string message)
  //      {

    //          _docNotifier.Notify(message);
    //          _logger.LogStatus(message);
    //      }
    //  }
}
