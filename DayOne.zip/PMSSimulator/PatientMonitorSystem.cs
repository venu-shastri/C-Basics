﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSSimulator
{
    class PatientMonitorSystem
    {
        Patient _patientTobeMonitored;
        bool isSimulationEndRequested = false;
        PatientCriticalStateListenerAdpater criticalStateListenerAdapter;

        public PatientMonitorSystem(Patient patientRef,PatientCriticalStateListenerAdpater listnerAdpater)
        {
            this._patientTobeMonitored = patientRef;
            this.criticalStateListenerAdapter = listnerAdpater;
        }
        public void On() {
            Console.WriteLine("PMS Turned On");
        }
        public void Off() {

            Console.WriteLine("PMS Turned Off");
        }
        public void StartMonitoring()
        {
            while(!isSimulationEndRequested)
            {
               PatientDiagnosticParameter parmeter=
                    this._patientTobeMonitored.GetCurrentStatus();
                if(parmeter.CurrentBPValue < 80 || parmeter.CurrentBPValue> 120)
                {
                    //Notify Observers
                    this.criticalStateListenerAdapter.
                        Invoke($"Patient Condition Critical - BP Range Value {parmeter.CurrentBPValue}");
                }
                System.Threading.Thread.Sleep(5000);
            }
        }
        public void StopMonitoring()
        {
            isSimulationEndRequested = true;
        }
    }
}
