﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSSimulator
{
    public  class RandomValueGenerator {

        private RandomValueGenerator() { }

        public static readonly RandomValueGenerator Instance = new RandomValueGenerator();


        Random obj = new Random();

        public  int GetRandomValue(int min, int max)
        {
            return obj.Next(min, max);
        }
    }

    public class Patient
    {
        public PatientDiagnosticParameter GetCurrentStatus()
        {
            return new 
                PatientDiagnosticParameter {
                CurrentBPValue = RandomValueGenerator.
                Instance.GetRandomValue(40, 180) };
        }
    }
}
