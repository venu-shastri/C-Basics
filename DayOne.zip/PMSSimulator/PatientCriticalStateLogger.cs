﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSSimulator
{
    //Observer
   public class PatientCriticalStateLogger
    {
        public void LogStatus(string message)
        {
            Console.WriteLine($"PatientCriticalStateLogger Logger Message - {message}");
        }
    }
}
