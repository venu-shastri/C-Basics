﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSSimulator
{

    //Observer
    public class DutyDoctorNotifier
    {
        public void Notify(string docIdentity)
        {
            string message = $"Sending Notification to Doctor {docIdentity}";
            Console.WriteLine(message);
        }
    }
}
