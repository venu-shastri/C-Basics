﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSSimulator
{
    class Program
    {
        

        static void Main(string[] args)
        {
            DutyDoctorNotifier _adapteeObjectRef = new DutyDoctorNotifier();
            PatientCriticalStateLogger _loggerAdapteeObjectRef = new PatientCriticalStateLogger();


            Patient _patient = new Patient();

            PatientCriticalStateListenerAdpater _adapter =
                new PatientCriticalStateListenerAdpater(_adapteeObjectRef.Notify);

            PatientCriticalStateListenerAdpater _newAdapter=
                new PatientCriticalStateListenerAdpater(_loggerAdapteeObjectRef.LogStatus);

            PatientCriticalStateListenerAdpater _multiCastAdpater = _adapter + _newAdapter;



            PatientMonitorSystem _device = new PatientMonitorSystem(_patient, _multiCastAdpater);
            _device.On();
            _device.StartMonitoring();
            
        }
    }
}
