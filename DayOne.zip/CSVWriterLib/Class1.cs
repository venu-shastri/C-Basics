﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVWriterLib
{

    [AttributeUsage(AttributeTargets.Property)]
    public class CSVLineMemberAttribute : System.Attribute
    {
        string headerName;
        int order;

        public CSVLineMemberAttribute(string _headerName)
        {
            this.headerName = _headerName;
        }

        public int Order
        {
            get { return this.order; }
            set { this.order = value; }
        }
        public string HeaderName
        {
            get { return this.headerName; }
        }
    }

    public struct CSVLineMember
    {
        //metadata
        public string HeaderName { get; set; }
        //object memory
        public object Value { get; set; }
        //metadata
        public int Order { get; set; }
    }
    public class CSVFormatter
    {
        string _filePath;
        public CSVFormatter(string filePath)
        {
            this._filePath = filePath;
        }
        public List<CSVLineMember> WriteObject(object source)
        {
            //Find Properties - public , instance , No array , collection , composition

            List<CSVLineMember> memberList = new List<CSVLineMember>();
            System.Type _udt = source.GetType();

            System.Reflection.PropertyInfo[] propertyList = _udt.GetProperties(
                                     System.Reflection.BindingFlags.Public |
                                     System.Reflection.BindingFlags.Instance);
            if (propertyList.Length > 0)
            {

                foreach (System.Reflection.PropertyInfo property in propertyList)
                {
                    CSVLineMemberAttribute[] attributes =
                        property.GetCustomAttributes(typeof(CSVLineMemberAttribute), false) as
                        CSVLineMemberAttribute[];
                    if (attributes.Length > 0)
                    {
                        CSVLineMember _member = new CSVLineMember
                        {
                            HeaderName = attributes[0].HeaderName,
                            Order = attributes[0].Order,
                            Value = property.GetValue(source)


                        };
                        memberList.Add(_member);
                    }



                }

            }
            return memberList;
        }
    }
}