﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyntaxSugar
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] items = { "Dell", "Nokia", "Apple", "Lenovo", "Lava" };

            Select<string>(items, new Func<string, bool>(Program.CheckStringLengthGreterThanFour));
            Select<string>(items, new Func<string, bool>(Program.CheckStringStartsWithN));

            Func<string, bool> endsWirtPredicate = (string item) => { return item.EndsWith("a"); };

            Select<string>(items, endsWirtPredicate);
            Select<string>(items, endsWirtPredicate);
            Select<string>(items, endsWirtPredicate);
            Select<string>(items, endsWirtPredicate);
        }
        static bool CheckStringLengthGreterThanFour(string item)
        {
            return item.Length > 4;
        }
        static bool CheckStringStartsWithN(string item)
        {
            return item.StartsWith("N");
        }
        static List<T> Select<T>(T[] source,Func<T,bool> predicate)
        {
            List<T> _projectionList = new List<T>();
            for(int i = 0; i < source.Length; i++)
            {
                if (predicate
                    (source[i]))
                {
                    _projectionList.Add(source[i]);
                }
            }
            return _projectionList;

        }

        //select name from employeeTable where Len(name) = 4

        //QueryEngine(query)

        
    }
}
