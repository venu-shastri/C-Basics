﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeyWords
{
    class A:System.Dynamic.DynamicObject {

        public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
        {
            result = null;
            return true;
        }
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            A obj_a = new A();// .field 

            Object newObj = new A();
            
            dynamic obj = new A();

            obj.Test();//Resolve @Runtime - > CSharp.RuntimeBinder

            var varObj = new A();

           


        }


    }
}
