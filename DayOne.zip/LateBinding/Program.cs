﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LateBinding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Reader Version");
            string version = Console.ReadLine();
            string strongName = $"CSVReader,Version={version},PublicKeyToken=ae2e28c9a01cf17b,Culture=Neutral";


            //Load Assembly From Cache
            System.Reflection.Assembly dllRef=System.Reflection.Assembly.Load(strongName);
            System.Reflection.Module _moduleRef=dllRef.GetModule("CSVReader.dll");

            //Metadata Search- UDT
             System.Type _udtRef=  _moduleRef.GetType("CSVReader.CSVCommentsReader");

            //Method Search
          System.Reflection.MethodInfo _methodInfo=
                _udtRef.GetMethod("GetContents", System.Reflection.BindingFlags.Instance 
                | System.Reflection.BindingFlags.Public);


            //Dynamic Method Invoke
            if (!_methodInfo.IsStatic)
            {
                   //new <Type>();
                Object objRef=System.Activator.CreateInstance(_udtRef);
               Object returnValue= _methodInfo.Invoke(objRef, new Object[] { });
                Console.WriteLine(returnValue.ToString());
            }
        }
    }
}


