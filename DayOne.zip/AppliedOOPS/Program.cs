﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppliedOOPS
{
    class Program
    {
        static void Main(string[] args)
        {
            //Substitution
            AnalyticResultPresenter presenter = new ConsolePresenter();
            SentimentScoreCalculator calculator = new BellCurveSentimentScoreCalculator();
            CommentReader reader = new CsvReader();

            PatientCommentAnalyticsProcessor _processor = 
                new PatientCommentAnalyticsProcessor(reader, presenter, calculator);
            _processor.Process();


        }
    }
}
