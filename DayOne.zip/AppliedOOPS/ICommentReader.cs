﻿using System.Collections.Generic;

namespace AppliedOOPS
{
    public interface ICommentReader
    {
        List<CommentModel> GetAllComments();
    }
}