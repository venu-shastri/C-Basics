﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppliedOOPS
{
   
   
    public class CsvReader : ICommentReader
    {
        public bool VerifyFileExistance(string path)
        {
            return false;
        }
        public CommentModel ReadAndProcessEachLine(string line)
        {
            return null;
        }
        public  List<CommentModel> GetAllComments()
        {
            return null;
        }
        
    }
}
