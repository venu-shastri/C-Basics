﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppliedOOPS
{
    //High Level Module
  public  class PatientCommentAnalyticsProcessor
    {
        //Dependency
        ICommentReader _reader = null;
        AnalyticResultPresenter _presenter = null;
        ISentimentScoreCalculator _calculator = null;

        //Dependency Injection-> Parameters
        //Constructor Injection
        public PatientCommentAnalyticsProcessor(
            ICommentReader readerRef,
            AnalyticResultPresenter presenterRef,
            ISentimentScoreCalculator calculatorRef)
        {
            this._reader = readerRef;
            this._presenter = presenterRef;
            this._calculator = calculatorRef;
        }

       
        public void Process()
        {
           List<CommentModel> _comments= this._reader.GetAllComments();
            foreach(CommentModel comment in _comments)
            {
               AnalyticResult _result= this._calculator.CalculateSentimentScore(comment);
                this._presenter.PresentAnalyticResult(_result);

            }
        }
    }
}
