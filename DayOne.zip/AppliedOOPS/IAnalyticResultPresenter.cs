﻿namespace AppliedOOPS
{
    public interface IAnalyticResultPresenter
    {
        void PresentAnalyticResult(AnalyticResult result);
    }
}