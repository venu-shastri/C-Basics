﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppliedOOPS
{
    public interface ISentimentScoreCalculator
    {
         AnalyticResult CalculateSentimentScore(CommentModel comment);
    }
    public  class BellCurveSentimentScoreCalculator:ISentimentScoreCalculator
    {
        public  AnalyticResult CalculateSentimentScore(CommentModel comment)
        {
            return null;
        }
    }
}
