﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVWriterTestApp
{
    
    public class AnalyticResult
    {
        public string CommentId { get; set; }

        [CSVWriterLib.CSVLineMember("COMMENTTEXT", Order = 3)]
        public string CommentText { get; set; }

        [CSVWriterLib.CSVLineMember("COMMENTSCORE", Order = 2)]
        public int SentimentScore { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<AnalyticResult> resultSet = new List<AnalyticResult>()
            {
                new AnalyticResult(){ CommentId="C100", CommentText="Food is Good", SentimentScore=4},
                new AnalyticResult(){ CommentId="C200", CommentText="Food is Good", SentimentScore=4},
                new AnalyticResult(){ CommentId="C300", CommentText="Food is Good", SentimentScore=3},
                new AnalyticResult(){ CommentId="C400", CommentText="Food is Good", SentimentScore=4},
                new AnalyticResult(){ CommentId="C500", CommentText="Food is Good", SentimentScore=2}
            };
            
            CSVWriterLib.CSVFormatter writerObj = new CSVWriterLib.CSVFormatter("test.csv");
            foreach(AnalyticResult result in resultSet)
            {
             List<CSVWriterLib.CSVLineMember>  lineMemberList=   writerObj.WriteObject(result);
            }

        }
    }
}
