﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    class SubscriberOne
    {
        public void Subscribe(string article)
        {
            Console.WriteLine("SubscriberOne Notified " + article);
        }
    }
}
