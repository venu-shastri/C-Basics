﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            SubscriberOne _one = new SubscriberOne();
            SubscriberTwo _two = new SubscriberTwo();
            SubScriberThree _three = new SubScriberThree();

            Action<string> _distibutorForSubcriberOne = new Action<string>(_one.Subscribe);
            Action<string> _distibutorForSubcriberTwo = new Action<string>(_two.Subscribe);
            Action<string> _distibutorForSubcriberThree = new Action<string>(_three.Subscribe);

            Action<string> _distibutorForSubcriberfour = (string msg) => {

                /*Method Body */

            };


            Publisher _publisher = new Publisher();
            _publisher.OnNewArticle += _distibutorForSubcriberOne;
            //_publisher.Add_OnNewArticle(_distibutorForSubcriberOne);

             _publisher.OnNewArticle += _distibutorForSubcriberTwo;
            //_publisher.Add_OnNewArticle(_distibutorForSubcriberTwo);


            _publisher.OnNewArticle += _distibutorForSubcriberThree;
            //_publisher.Add_OnNewArticle(_distibutorForSubcriberThree);

            while (true)
            {
                Console.WriteLine("Press Any Key To Publish New Article");
                Console.ReadKey();
                _publisher.PublishArticle();
            }


        }
    }
}
