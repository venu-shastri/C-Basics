﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
   // public delegate void Distributor(string article);

    public class Publisher
    {
        //Encapsulate
        //EVENT 
        // private <DelegateName> <EventName>;

        //   private Distributor OnNewArticle;

        public event Action<string> OnNewArticle;

        //public void Add_OnNewArticle(Distributor _subscriberRef)
        //{
        //    this.OnNewArticle += _subscriberRef;
        //}
        //public void Remove_OnNewArticle(Distributor _subscriberRef)
        //{
        //    this.OnNewArticle -= _subscriberRef;

        //}

        public void PublishArticle()
        {
            if(OnNewArticle!=null)
            {
                this.OnNewArticle.Invoke("New Article");
            }
        }
    }
}
